"""
Email router Lambda: receives SNS messages from the tag compliance topic,
creates/manages dynamic email subscriptions for creator emails, and re-publishes
messages so creator emails receive notifications via SNS.
"""
import json
import logging
import os

import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

SNS_TOPIC_ARN = os.environ.get("SNS_TOPIC_ARN", "")


def lambda_handler(event, context):
    """Process SNS messages, create subscriptions for creator emails, re-publish for delivery."""
    if not SNS_TOPIC_ARN:
        logger.warning("SNS_TOPIC_ARN not set, skipping")
        return {"statusCode": 200}

    sns = boto3.client("sns")
    for record in event.get("Records", []):
        if record.get("EventSource") != "aws:sns":
            continue
        try:
            sns_msg = record.get("Sns", {})
            message_body = sns_msg.get("Message", "")
            subject = sns_msg.get("Subject", "EC2 Tag Compliance Notification")
            attrs = sns_msg.get("MessageAttributes", {})
            recipient_type = _get_attr_value(attrs, "recipient_type", "")
            recipient_email = _get_attr_value(attrs, "recipient_email", "")

            source = _get_attr_value(attrs, "source", "")

            # Only handle messages originating from the scanner Lambda; skip any
            # messages that the router has already republished to avoid loops.
            if source == "router":
                logger.info("Skipping router-originated message for %s", recipient_email or recipient_type)
                continue
            if source and source != "scanner":
                logger.warning("Unknown message source '%s'; skipping", source)
                continue

            if not recipient_type.startswith("creator") or not recipient_email:
                continue

            # Subscribe creator email if not already subscribed
            _ensure_email_subscribed(sns, recipient_email)

            # Re-publish so the subscription receives the message (for confirmed subscriptions)
            _republish_message(sns, message_body, subject, attrs)
        except Exception as e:
            logger.warning("Error processing record: %s", e, exc_info=True)

    return {"statusCode": 200}


def _get_attr_value(attrs: dict, key: str, default: str = "") -> str:
    """Extract string value from SNS message attributes."""
    if key not in attrs:
        return default
    val = attrs[key]
    if isinstance(val, dict) and "Value" in val:
        return (val.get("Value") or default).strip()
    return str(val).strip() if val else default


def _ensure_email_subscribed(sns, email: str) -> bool:
    """Subscribe email to topic with filter if not already subscribed. Returns True if subscribed or exists."""
    if not email or "@" not in email:
        return False
    try:
        resp = sns.list_subscriptions_by_topic(TopicArn=SNS_TOPIC_ARN)
        for sub in resp.get("Subscriptions", []):
            if sub.get("Endpoint") == email and sub.get("Protocol") == "email":
                if sub.get("SubscriptionArn") and sub["SubscriptionArn"] != "PendingConfirmation":
                    return True
                logger.info("Subscription for %s pending confirmation", email)
                return True

        sns.subscribe(
            TopicArn=SNS_TOPIC_ARN,
            Protocol="email",
            Endpoint=email,
            ReturnSubscriptionArn=True,
            Attributes={"FilterPolicy": json.dumps({"recipient_email": [email]})},
        )
        logger.info("Created subscription for %s (pending confirmation)", email)
        return True
    except ClientError as e:
        logger.warning("Failed to subscribe %s: %s", email, e)
        return False


def _republish_message(sns, message_body: str, subject: str, attrs: dict) -> bool:
    """Re-publish message to topic so creator subscription receives it."""
    try:
        msg_attrs = _build_message_attributes(attrs)
        # Mark this publish as coming from the router so the router can skip it
        # on subsequent deliveries and avoid infinite re-processing.
        msg_attrs["source"] = {"DataType": "String", "StringValue": "router"}
        sns.publish(
            TopicArn=SNS_TOPIC_ARN,
            Message=message_body,
            Subject=subject,
            MessageAttributes=msg_attrs,
        )
        logger.info("Re-published message for creator delivery")
        return True
    except ClientError as e:
        logger.warning("Failed to re-publish: %s", e)
        return False


def _build_message_attributes(attrs: dict) -> dict:
    """Convert SNS record attributes to Publish API format."""
    result = {}
    for key, val in (attrs or {}).items():
        if isinstance(val, dict) and "Type" in val and "Value" in val:
            result[key] = {"DataType": val["Type"], "StringValue": str(val["Value"])}
    return result
